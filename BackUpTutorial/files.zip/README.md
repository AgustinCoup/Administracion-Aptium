# Backup automático de Aptium — Guía de configuración

---

## Paso 1: Encontrar mysqldump.exe

Según cómo tengas instalado MySQL, la ruta es distinta. Abrí el Explorador
de Windows y buscá `mysqldump.exe` en alguno de estos lugares típicos:

| Instalación | Ruta típica |
|-------------|------------|
| XAMPP | `C:\xampp\mysql\bin\mysqldump.exe` |
| WAMP | `C:\wamp64\bin\mysql\mysql8.x.x\bin\mysqldump.exe` |
| MySQL oficial | `C:\Program Files\MySQL\MySQL Server 8.0\bin\mysqldump.exe` |
| Laragon | `C:\laragon\bin\mysql\mysql-8.x\bin\mysqldump.exe` |

Una vez que la encontrés, editá la variable `$MYSQLDUMP_EXE` en el script.

---

## Paso 2: Crear la Contraseña de Aplicación de Gmail

Gmail **no permite** usar tu contraseña normal en scripts. Necesitás
una "Contraseña de Aplicación", que es una clave de 16 caracteres
específica para este uso.

**Requisito previo:** tu cuenta Google debe tener activada la
Verificación en dos pasos.

**Cómo crearla:**

1. Ir a: https://myaccount.google.com/apppasswords
   (o Google → Cuenta → Seguridad → Contraseñas de aplicaciones)
2. En "Seleccionar app" elegir **Correo**
3. En "Seleccionar dispositivo" elegir **Equipo con Windows**
4. Hacer clic en **Generar**
5. Copiar la clave de 16 caracteres que aparece (ej: `abcd efgh ijkl mnop`)

Esa clave va en la variable `$GMAIL_PASS` del script, **incluyendo los espacios**.

> Si no ves la opción "Contraseñas de aplicaciones" en tu cuenta,
> primero activá la verificación en dos pasos desde:
> https://myaccount.google.com/security

---

## Paso 3: Editar el script

Abrir `backup_aptium.ps1` con el Bloc de notas y completar el bloque
de configuración al principio:

```powershell
$DB_NAME       = "aptium"              # nombre real de tu DB
$DB_USER       = "root"
$DB_PASS       = "tu_password_mysql"

$MYSQLDUMP_EXE = "C:\xampp\mysql\bin\mysqldump.exe"  # tu ruta real

$BACKUP_DIR    = "C:\Backups\Aptium"   # donde guardar los .zip

$GMAIL_FROM    = "tu_cuenta@gmail.com"
$GMAIL_PASS    = "abcd efgh ijkl mnop" # la clave de app del paso 2
$MAIL_TO       = "destino@gmail.com"
```

---

## Paso 4: Probar el script manualmente

Antes de programarlo, verificar que funcione. Abrir PowerShell como
Administrador y ejecutar:

```powershell
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
```

(Solo hay que hacerlo una vez. Permite ejecutar scripts locales.)

Luego ejecutar el script:

```powershell
& "C:\ruta\donde\guardaste\backup_aptium.ps1"
```

Deberías ver en consola:
```
[2025-01-15_08-00] Iniciando backup de 'aptium'...
Dump generado: 142.3 KB
Comprimido: 18.7 KB  →  C:\Backups\Aptium\aptium_backup_2025-01-15_08-00.zip
Mail enviado a destino@gmail.com
[2025-01-15_08-00] Backup completado exitosamente.
```

---

## Paso 5: Programar con el Programador de tareas de Windows

1. Buscar **"Programador de tareas"** en el menú inicio y abrirlo
2. En el panel derecho, clic en **"Crear tarea básica..."**
3. **Nombre:** `Backup Aptium DB`
4. **Desencadenador:** Diariamente, a las 02:00 (o el horario que prefieras)
5. **Acción:** Iniciar un programa
   - **Programa:** `powershell.exe`
   - **Argumentos:**
     ```
     -NonInteractive -WindowStyle Hidden -ExecutionPolicy RemoteSigned -File "C:\ruta\backup_aptium.ps1"
     ```
     *(reemplazar `C:\ruta\backup_aptium.ps1` con la ruta real del script)*
6. En **"Finalizar"**, tildar **"Abrir el cuadro de diálogo Propiedades"**
7. En la pestaña **"General"**:
   - Tildar **"Ejecutar tanto si el usuario inició sesión como si no"**
   - Tildar **"Ejecutar con los privilegios más altos"**
8. Clic en **Aceptar** e ingresar la contraseña de Windows cuando la pida

---

## Códigos de salida del script

| Código | Significado |
|--------|-------------|
| `0` | Todo OK — backup guardado y mail enviado |
| `1` | Error en mysqldump — backup NO se guardó |
| `2` | Backup guardado localmente, pero el mail falló |

Si la tarea programada falla, podés ver el código de salida en
Programador de tareas → historial de la tarea.

---

## Dónde quedan los archivos

Los backups se guardan en `C:\Backups\Aptium\` (o la carpeta que hayas
configurado) con nombres como:

```
aptium_backup_2025-01-15_02-00.zip
aptium_backup_2025-01-16_02-00.zip
aptium_backup_2025-01-17_02-00.zip
...
```

Cada `.zip` contiene el `.sql` completo con toda la estructura y datos
de la base de datos, listo para restaurar con:

```sql
mysql -u root -p aptium < aptium_backup_FECHA.sql
```
