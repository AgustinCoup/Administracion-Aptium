# ==============================================================================
# backup_aptium.ps1
# Backup automático de la base de datos Aptium
# Guarda el .sql comprimido localmente y lo envía por Gmail
#
# CONFIGURACIÓN: editar solo el bloque de abajo
# ==============================================================================

# ── CONFIGURACIÓN ─────────────────────────────────────────────────────────────

$DB_HOST       = "localhost"
$DB_PORT       = "3306"
$DB_NAME       = "aptium"           # nombre de tu base de datos
$DB_USER       = "root"             # usuario MySQL
$DB_PASS       = "tu_password_mysql" # contraseña MySQL

$MYSQLDUMP_EXE = "C:\xampp\mysql\bin\mysqldump.exe"  # ajustar según tu instalación

$BACKUP_DIR    = "C:\Backups\Aptium"  # carpeta donde se guardan los .zip localmente

$GMAIL_FROM    = "tu_cuenta@gmail.com"
$GMAIL_PASS    = "xxxx xxxx xxxx xxxx"  # Contraseña de Aplicación de Google (ver README)
$MAIL_TO       = "destino@gmail.com"   # puede ser la misma cuenta u otra

# ── FIN DE CONFIGURACIÓN ──────────────────────────────────────────────────────


# ── Preparar nombres de archivo ───────────────────────────────────────────────

$timestamp  = Get-Date -Format "yyyy-MM-dd_HH-mm"
$sqlFile    = Join-Path $env:TEMP "aptium_backup_$timestamp.sql"
$zipFile    = Join-Path $BACKUP_DIR "aptium_backup_$timestamp.zip"

# Crear carpeta de backups si no existe
if (-not (Test-Path $BACKUP_DIR)) {
    New-Item -ItemType Directory -Path $BACKUP_DIR | Out-Null
}

# ── Verificar que mysqldump existe ────────────────────────────────────────────

if (-not (Test-Path $MYSQLDUMP_EXE)) {
    Write-Error "No se encontró mysqldump.exe en: $MYSQLDUMP_EXE`nEditá la variable MYSQLDUMP_EXE en el script."
    exit 1
}

# ── Ejecutar mysqldump ────────────────────────────────────────────────────────

Write-Host "[$timestamp] Iniciando backup de '$DB_NAME'..."

$env:MYSQL_PWD = $DB_PASS   # pasar contraseña por variable de entorno (evita warning)

& $MYSQLDUMP_EXE `
    --host=$DB_HOST `
    --port=$DB_PORT `
    --user=$DB_USER `
    --single-transaction `
    --routines `
    --triggers `
    --add-drop-table `
    $DB_NAME | Out-File -FilePath $sqlFile -Encoding utf8

$env:MYSQL_PWD = ""         # limpiar la variable inmediatamente

if ($LASTEXITCODE -ne 0) {
    Write-Error "mysqldump falló con código $LASTEXITCODE. Backup abortado."
    Remove-Item $sqlFile -ErrorAction SilentlyContinue
    exit 1
}

# Verificar que el .sql no esté vacío
$sqlSize = (Get-Item $sqlFile).Length
if ($sqlSize -lt 100) {
    Write-Error "El archivo .sql generado parece vacío ($sqlSize bytes). Verificá las credenciales de MySQL."
    Remove-Item $sqlFile -ErrorAction SilentlyContinue
    exit 1
}

Write-Host "Dump generado: $([math]::Round($sqlSize / 1KB, 1)) KB"

# ── Comprimir a .zip ──────────────────────────────────────────────────────────

Compress-Archive -Path $sqlFile -DestinationPath $zipFile -CompressionLevel Optimal
Remove-Item $sqlFile   # borrar el .sql temporal

$zipSize = (Get-Item $zipFile).Length
Write-Host "Comprimido: $([math]::Round($zipSize / 1KB, 1)) KB  →  $zipFile"

# ── Enviar por Gmail ──────────────────────────────────────────────────────────

$fechaLegible = Get-Date -Format "dd/MM/yyyy HH:mm"
$asunto       = "Backup Aptium — $fechaLegible"
$cuerpo       = "Backup automático de la base de datos Aptium.`n`nFecha: $fechaLegible`nArchivo: $(Split-Path $zipFile -Leaf)`nTamaño: $([math]::Round($zipSize / 1KB, 1)) KB"

try {
    $smtp = New-Object System.Net.Mail.SmtpClient("smtp.gmail.com", 587)
    $smtp.EnableSsl   = $true
    $smtp.Credentials = New-Object System.Net.NetworkCredential($GMAIL_FROM, $GMAIL_PASS)

    $mensaje = New-Object System.Net.Mail.MailMessage
    $mensaje.From    = $GMAIL_FROM
    $mensaje.To.Add($MAIL_TO)
    $mensaje.Subject = $asunto
    $mensaje.Body    = $cuerpo

    $adjunto = New-Object System.Net.Mail.Attachment($zipFile)
    $mensaje.Attachments.Add($adjunto)

    $smtp.Send($mensaje)
    $adjunto.Dispose()
    $mensaje.Dispose()

    Write-Host "Mail enviado a $MAIL_TO"
} catch {
    Write-Error "El backup se guardó localmente pero falló el envío del mail: $_"
    exit 2   # exit 2 = backup OK, mail falló
}

Write-Host "[$timestamp] Backup completado exitosamente."
exit 0
